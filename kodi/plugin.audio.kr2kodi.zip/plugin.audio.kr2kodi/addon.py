# -*- coding: utf-8 -*-

import sys, xbmcgui, xbmcplugin
import urllib, urllib2, re

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'audio')

def url_func(url):
    WebSock = urllib.urlopen(url)
    WebHTML = WebSock.read()
    WebSock.close()
    return WebHTML

def kbs_func(code):
    Base_URL = 'http://onair.kbs.co.kr/index.html?sname=onair&stype=live&ch_code=' + code
    WebHTML = url_func(Base_URL)
    Temp_Web_URL = re.compile('http://.*Key-Pair-Id=[0-9A-Z]*').findall(WebHTML)
    url = Temp_Web_URL[0].split('\\', 1)[0]
    return url

def mbc_func(code):
    Base_URL = 'http://miniplay.imbc.com/AACLiveURL.ashx?channel=' + code + '&agent=android&protocol=M3U8'
    url = url_func(Base_URL)
    ### Double query
    #url_root = url.rsplit('/', 1)[0]
    #M3U = url_func(url)
    #M3U = re.compile('.*m3u.*').findall(M3U)[0]
    #url = url_root + '/' + M3U
    ###
    return url

def sbs_func(code1, code2):

    Base_URL = 'http://api.sbs.co.kr/vod/_v1/Onair_Media_Auth_Security.jsp?channelPath=' + code1 + '&streamName=' + code2 + '.stream&playerType=mobile'
    data = url_func(Base_URL)

    import base64, Cryptodome.Cipher.DES

    key = b'7d1ff4ea8925c225'
    ciphertext = base64.b64decode(data)
    cipher = Cryptodome.Cipher.DES.new(key[:8], mode=Cryptodome.Cipher.DES.MODE_ECB)
    unpad = lambda s : s[0:-ord(s[-1])]
    text = unpad(cipher.decrypt(ciphertext))
    url = text.decode('utf8')

    ### Double query
    #print(url)
    #M3U = url_func(url)
    #url = re.compile('.*m3u.*').findall(M3U)[0]
    ###
    return url

def ch_func(ch):
    if   ch == chs[0]:
        url = kbs_func('24')
        icon = 'https://i.imgur.com/TQ9uiRS.png'
    elif ch == chs[1]:
        url = kbs_func('25')
        icon = 'https://i.imgur.com/uXyS8h8.png'
    elif ch == chs[2]:
        url = mbc_func('chm')
        icon = 'https://i.imgur.com/ymwqEZ9.png'
    elif ch == chs[3]:
        url = mbc_func('mfm')
        icon = 'https://i.imgur.com/XsUtjRb.png'
    elif ch == chs[4]:
        url = sbs_func('powerpc',  'powerfm')
        icon = 'https://image.cloud.sbs.co.kr/play/radio/power.jpg'
    elif ch == chs[5]:
        url = sbs_func('lovepc',   'lovefm')
        icon = 'https://image.cloud.sbs.co.kr/play/radio/love.jpg'
    else:
        print 'Argument(s) is missing or invalid!'
        quit()
    return url, icon

def add_func(ch, url, icon):
    li = xbmcgui.ListItem(ch)
    li.setArt({'icon': icon, 'thumb': icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

chs = ["KBS 클래식 FM", "KBS 쿨 FM", "MBC 표준FM", "MBC FM4U", "SBS 파워 FM", "SBS 러브 FM"]
for ch in chs:
    url, icon = ch_func(ch)
    add_func(ch, url, icon)

add_func('CBS 음악 FM', 'http://aac.cbs.co.kr/cbs939/cbs939.stream/playlist.m3u8', 'https://i.imgur.com/o6YpURo.png')
add_func('EBS FM', 'http://ebsonair.ebs.co.kr/fmradiofamilypc/familypc1m/playlist.m3u8', 'http://m.ebs.co.kr/common/img/ebs_logo.png')
add_func('tbs FM', 'http://tbs.hscdn.com/tbsradio/fm/playlist.m3u8', 'http://m.tbs.seoul.kr/common/images/default/tbs_logo.jpg')
add_func('국악 FM', 'http://mgugaklive.nowcdn.co.kr/gugakradio/gugakradio.stream/playlist.m3u8', 'https://pbs.twimg.com/profile_images/883196509982011392/l7yA_yVP_400x400.jpg')

xbmcplugin.endOfDirectory(addon_handle)
