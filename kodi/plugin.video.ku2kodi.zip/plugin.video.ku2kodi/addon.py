# -*- coding: utf-8 -*-

import sys, xbmcgui, xbmcplugin
import urllib, urllib2, re

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'videos')

def url_func(url):
    WebSock = urllib.urlopen(url)
    WebHTML = WebSock.read()
    WebHTML = WebHTML.decode('utf-8')
    WebSock.close()
    return WebHTML

def ut_func(ch):
    Base_URL = 'http://www.youtube.com/' + ch
    WebHTML = url_func(Base_URL)
    Temp_Web_URL = re.compile('"videoId":"[0-9a-zA-Z-_]*"').findall(WebHTML)
    url = Temp_Web_URL[0].split('"', 4)[3]
    url = 'plugin://plugin.video.youtube/play/?video_id=' + url
    return url

def ch_func(ch):
    if   ch == chs[0]:
        url = ut_func('user/seoultbstv/featured')
    elif ch == chs[1]:
        url = ut_func('channel/UCTHCOPwqNfZ0uiKOvFyhGwg')
    elif ch == chs[2]:
        url = ut_func('user/ytnnews24')
    elif ch == chs[3]:
        url = ut_func('channel/UCDww6ExpwQS0TzmREIOo40Q')
    elif ch == chs[4]:
        url = ut_func('user/ytnscience')
    elif ch == chs[5]:
        url = ut_func('channel/UCsOW9TPy2TKkqCchUHL04Fg')
    else:
        print("Argument is missing or invalid!")
        quit()
    return url

def add_func(ch, url):
    li = xbmcgui.ListItem(ch)
    li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(addon_handle, url, li)

chs = ["tbs TV", "연합뉴스", "YTN 라이브", "YTN 라이프", "YTN 사이언스", "맛있는 녀석들"]
for ch in chs:
    url = ch_func(ch)
    add_func(ch, url)

xbmcplugin.endOfDirectory(addon_handle)
