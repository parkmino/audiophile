# -*- coding: utf-8 -*-

import sys, xbmcgui, xbmcplugin
import urllib, urllib2, re

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'video')

def url_func(url):
    WebSock = urllib.urlopen(url)
    WebHTML = WebSock.read()
    WebSock.close()
    return WebHTML

def kbs_func(code):
    Base_URL = 'http://onair.kbs.co.kr/index.html?sname=onair&stype=live&ch_code=' + code
    WebHTML = url_func(Base_URL)
    Temp_Web_URL = re.compile('http://.*Key-Pair-Id=[0-9A-Z]*').findall(WebHTML)
    url = Temp_Web_URL[0].split('\\', 1)[0]
    return url

def sbs_func(code1, code2):

    Base_URL = 'http://api.sbs.co.kr/vod/_v1/Onair_Media_Auth_Security.jsp?channelPath=' + code1 + '&streamName=' + code2 + '.stream&playerType=mobile'
    data = url_func(Base_URL)

    import base64, Cryptodome.Cipher.DES

    key = b'7d1ff4ea8925c225'
    ciphertext = base64.b64decode(data)
    cipher = Cryptodome.Cipher.DES.new(key[:8], mode=Cryptodome.Cipher.DES.MODE_ECB)
    unpad = lambda s : s[0:-ord(s[-1])]
    text = cipher.decrypt(ciphertext)
    url = text.decode('utf8')

    ### Double query
    #print(url)
    #M3U = url_func(url)
    #url = re.compile('.*m3u.*').findall(M3U)[0]
    ###
    return url

def ch_func(ch):
    if   ch == chs[0]:
        url = kbs_func('11')
        #icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/10/11/1539237809933_114600.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/KBS-1TV-1.jpg'
    elif ch == chs[1]:
        url = kbs_func('12')
        #icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/10/11/1539237810007_114611.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/KBS-2TV-1.jpg'
    elif ch == chs[2]:
        url = kbs_func('14')
        icon = 'http://padmin.static.kbs.co.kr/live/2019/9/2/1567407662408_155622.png'
    elif ch == chs[3]:
        url = kbs_func('81')
        icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/4/3/1522738325143_70038.png'
    elif ch == chs[4]:
        url = kbs_func('N91')
        #icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/4/3/1522738393154_70050.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/K06.jpg'
    elif ch == chs[5]:
        url = kbs_func('N92')
        #icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/4/3/1522738393212_70061.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/K04.jpg'
    elif ch == chs[6]:
        url = kbs_func('N94')
        #icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/4/3/1522738393255_70072.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/K09.jpg'
    elif ch == chs[7]:
        url = kbs_func('N93')
        #icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/4/3/1522738393311_70083.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/K05.jpg'
    elif ch == chs[8]:
        url = kbs_func('N96')
        icon = 'http://padmin.s3-website.ap-northeast-2.amazonaws.com/live/2018/4/3/1522738393376_70094.png'
    elif ch == chs[9]:
        url = sbs_func('sbsch6pc', 'sbsch60')
        #icon = 'http://i.imgur.com/K2ztoDT.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/S01.jpg'
    elif ch == chs[10]:
        url = sbs_func('sbspluspc', 'sbsplus0')
        #icon = 'http://i.imgur.com/asfyrTm.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/S03.jpg'
    elif ch == chs[11]:
        url = sbs_func('sbscnbc',   'sbscnbc0')
        #icon = 'http://i.imgur.com/SfDs4qN.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/S06.jpg'
    elif ch == chs[12]:
        url = sbs_func('sbsetvpc',  'sbsetv0')
        #icon = 'http://i.imgur.com/D1EYJmr.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/S04.jpg'
    elif ch == chs[13]:
        url = sbs_func('sbsgolf',   'sbsgolf')
        icon = 'http://i.imgur.com/HdS0GNV.png'
    elif ch == chs[14]:
        url = sbs_func('sbsmtvpc',  'sbsmtv0')
        #icon = 'http://i.imgur.com/OeSJ9Ik.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/S09.jpg'
    elif ch == chs[15]:
        url = sbs_func('sbsnickpc', 'sbsnick0')
        #icon = 'http://i.imgur.com/K2ztoDT.png'
        icon = 'https://img.pooq.co.kr/BMS/Channelimage30/image/S10.jpg'
    elif ch == chs[16]:
        url = sbs_func('sbsespn',   'sbsespn0')
        icon = 'http://i.imgur.com/j1vHAu6.png'
    else:
        print 'Argument(s) is missing or invalid!'
        quit()
    return url, icon

def add_func(ch, url, icon):
    li = xbmcgui.ListItem(ch)
    li.setArt({'icon': icon, 'thumb': icon})
    xbmcplugin.addDirectoryItem(addon_handle, url, li)

chs = ["KBS 1TV", "KBS 2TV", "KBS 월드", "KBS24", "KBSN 드라마", "KBSN 조이", "KBSN W", "KBSN 라이프", "KBSN 키즈", "SBS", "SBS 플러스", "SBS CNBC", "SBS funE", "SBS 골프", "SBS MTV", "SBS nick", "SBS 스포츠"]

for ch in chs:
    url, icon = ch_func(ch)
    add_func(ch, url, icon)

add_func('EBS1',  'http://ebsonair.ebs.co.kr/groundwavefamilypc/familypc1m/playlist.m3u8', 'https://img.pooq.co.kr/BMS/Channelimage30/image/E01.jpg')
add_func('EBS2',  'http://ebsonair.ebs.co.kr/ebs2familypc/familypc1m/playlist.m3u8', 'https://img.pooq.co.kr/BMS/Channelimage30/image/E07.jpg')
add_func('EBSU',  'http://ebsonair.ebs.co.kr/ebsufamilypc/familypc1m/playlist.m3u8', 'https://nsimg.kbs.co.kr/data/news/2018/12/05/4088340_CwR.jpg')
add_func('EBSi',  'http://ebsonair.ebs.co.kr/plus1familypc/familypc1m/playlist.m3u8', 'https://nsimg.kbs.co.kr/data/news/2018/12/05/4088340_CwR.jpg')
add_func('EBS+2', 'http://ebsonair.ebs.co.kr/plus2familypc/familypc1m/playlist.m3u8', 'https://nsimg.kbs.co.kr/data/news/2018/12/05/4088340_CwR.jpg')
add_func('EBSe',  'http://ebsonair.ebs.co.kr/plus3familypc/familypc1m/playlist.m3u8', 'https://nsimg.kbs.co.kr/data/news/2018/12/05/4088340_CwR.jpg')
add_func('국악 TV', 'http://mgugaklive.nowcdn.co.kr/gugakvideo/gugakvideo.stream/playlist.m3u8', 'https://pbs.twimg.com/profile_images/883196509982011392/l7yA_yVP_400x400.jpg')

xbmcplugin.endOfDirectory(addon_handle)