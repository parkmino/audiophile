-- {"order":0,"arguments":[]}
result = mympd.os_capture("sudo poweroff")
return result
