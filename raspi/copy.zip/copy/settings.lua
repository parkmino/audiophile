-- {"order":0,"arguments":[]}
mympd.os_capture("ttyd -o -O -W -p 8080 bash audio-config&")

