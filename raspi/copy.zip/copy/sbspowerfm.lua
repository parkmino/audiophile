-- {"order":0,"arguments":[]}
result = mympd.os_capture("kr2mpd sbsp")
return result
