-- {"order":0,"arguments":[]}
result = mympd.os_capture("sudo reboot")
return result
