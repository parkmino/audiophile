-- {"order":0,"arguments":[]}
result = mympd.os_capture("kr2mpd mbc4u")
return result
