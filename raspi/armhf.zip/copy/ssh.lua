-- {"order":0,"arguments":[]}
result = mympd.os_capture("sudo systemctl start ssh")
return result
