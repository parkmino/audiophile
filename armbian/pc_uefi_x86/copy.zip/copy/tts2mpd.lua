-- {"order":0,"file":"","version":0,"arguments":["text"]}
-- tts2mpd helper functions
if mympd_arguments.text == "" then
    cmd = string.format("tts2mpd")
else
    cmd = string.format("tts2mpd %s 2>/dev/null", mympd_arguments.text)
end
mympd.log(6, "running command: " ..cmd)
local output = mympd.os_capture(cmd)
return output