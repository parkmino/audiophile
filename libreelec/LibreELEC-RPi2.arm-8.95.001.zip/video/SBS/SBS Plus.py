import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs +', shell=True)

listitem = xbmcgui.ListItem('SBS Plus')
xbmc.Player().play(url, listitem)
