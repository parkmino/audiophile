import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs g', shell=True)

listitem = xbmcgui.ListItem('SBS Golf')
xbmc.Player().play(url, listitem)
