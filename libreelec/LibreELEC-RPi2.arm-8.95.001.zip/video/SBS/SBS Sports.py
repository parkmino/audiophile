import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs s', shell=True)

listitem = xbmcgui.ListItem('SBS Sports')
xbmc.Player().play(url, listitem)
