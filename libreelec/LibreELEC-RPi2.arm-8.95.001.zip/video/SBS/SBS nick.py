import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs n', shell=True)

listitem = xbmcgui.ListItem('SBS nikelodeon')
xbmc.Player().play(url, listitem)
