import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs m', shell=True)

listitem = xbmcgui.ListItem('SBS MTV')
xbmc.Player().play(url, listitem)
