import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs f', shell=True)

listitem = xbmcgui.ListItem('SBS funE')
xbmc.Player().play(url, listitem)
