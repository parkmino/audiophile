import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs 6', shell=True)

listitem = xbmcgui.ListItem('SBS')
xbmc.Player().play(url, listitem)
