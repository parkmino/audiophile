import subprocess, xbmc, xbmcgui

url = subprocess.check_output('sbs c', shell=True)

listitem = xbmcgui.ListItem('SBS CNBC')
xbmc.Player().play(url, listitem)
