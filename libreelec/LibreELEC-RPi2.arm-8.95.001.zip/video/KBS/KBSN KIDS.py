import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs k', shell=True)

listitem = xbmcgui.ListItem('KBSN KIDS')
xbmc.Player().play(url, listitem)
