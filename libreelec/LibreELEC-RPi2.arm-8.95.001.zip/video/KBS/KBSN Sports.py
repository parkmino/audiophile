import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs s', shell=True)

listitem = xbmcgui.ListItem('KBSN Sports')
xbmc.Player().play(url, listitem)
