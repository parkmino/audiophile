import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs l', shell=True)

listitem = xbmcgui.ListItem('KBSN Life')
xbmc.Player().play(url, listitem)
