import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs 2tv', shell=True)

listitem = xbmcgui.ListItem('KBS 2TV')
xbmc.Player().play(url, listitem)
