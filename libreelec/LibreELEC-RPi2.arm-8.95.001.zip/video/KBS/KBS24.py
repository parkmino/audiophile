import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs 24', shell=True)

listitem = xbmcgui.ListItem('KBS24')
xbmc.Player().play(url, listitem)
