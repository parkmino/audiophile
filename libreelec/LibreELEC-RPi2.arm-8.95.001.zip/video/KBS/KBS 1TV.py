import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs 1tv', shell=True)

listitem = xbmcgui.ListItem('KBS 1TV')
xbmc.Player().play(url, listitem)
