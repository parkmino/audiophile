import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs w', shell=True)

listitem = xbmcgui.ListItem('KBS WORLD')
xbmc.Player().play(url, listitem)
