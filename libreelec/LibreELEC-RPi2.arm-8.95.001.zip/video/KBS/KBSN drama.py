import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs d', shell=True)

listitem = xbmcgui.ListItem('KBSN drama')
xbmc.Player().play(url, listitem)
