import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs j', shell=True)

listitem = xbmcgui.ListItem('KBSN joy')
xbmc.Player().play(url, listitem)
