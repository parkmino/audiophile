import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kbs W', shell=True)

listitem = xbmcgui.ListItem('KBSN W')
xbmc.Player().play(url, listitem)
