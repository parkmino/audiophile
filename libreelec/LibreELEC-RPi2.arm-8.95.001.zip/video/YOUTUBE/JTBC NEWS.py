import subprocess, xbmc

url = subprocess.check_output('ut2kodi jtbc', shell=True)

xbmc.executebuiltin("PlayMedia("+url+")")
