import subprocess, xbmc

url = subprocess.check_output('ut2kodi yonhap', shell=True)

xbmc.executebuiltin("PlayMedia("+url+")")
