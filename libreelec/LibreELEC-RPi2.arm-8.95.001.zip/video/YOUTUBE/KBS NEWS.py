import subprocess, xbmc

url = subprocess.check_output('ut2kodi kbs_news', shell=True)

xbmc.executebuiltin("PlayMedia("+url+")")
