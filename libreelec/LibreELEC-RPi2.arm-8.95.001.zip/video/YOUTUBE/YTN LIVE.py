import subprocess, xbmc

url = subprocess.check_output('ut2kodi ytn', shell=True)

xbmc.executebuiltin("PlayMedia("+url+")")
