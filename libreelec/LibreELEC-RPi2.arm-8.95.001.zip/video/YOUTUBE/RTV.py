import subprocess, xbmc

url = subprocess.check_output('ut2kodi rtv', shell=True)

xbmc.executebuiltin("PlayMedia("+url+")")
