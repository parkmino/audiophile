import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kr2url mbc4u', shell=True)

listitem = xbmcgui.ListItem('MBC FM4U')
xbmc.Player().play(url, listitem)
