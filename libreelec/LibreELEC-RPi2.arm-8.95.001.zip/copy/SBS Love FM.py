import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kr2url sbsl', shell=True)

listitem = xbmcgui.ListItem('SBS Love FM')
xbmc.Player().play(url, listitem)
