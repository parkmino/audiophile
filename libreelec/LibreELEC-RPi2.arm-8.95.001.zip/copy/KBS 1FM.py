import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kr2url 1fm', shell=True)

listitem = xbmcgui.ListItem('KBS Classic FM')
xbmc.Player().play(url, listitem)
