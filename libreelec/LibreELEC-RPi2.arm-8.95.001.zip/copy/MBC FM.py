import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kr2url mbcfm', shell=True)

listitem = xbmcgui.ListItem('MBC FM')
xbmc.Player().play(url, listitem)
