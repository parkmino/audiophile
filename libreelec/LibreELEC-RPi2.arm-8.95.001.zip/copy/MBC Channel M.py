import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kr2url mbcm', shell=True)

listitem = xbmcgui.ListItem('MBC Channel M')
xbmc.Player().play(url, listitem)
