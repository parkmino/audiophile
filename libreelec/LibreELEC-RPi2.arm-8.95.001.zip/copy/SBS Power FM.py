import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kr2url sbsp', shell=True)

listitem = xbmcgui.ListItem('SBS Power FM')
xbmc.Player().play(url, listitem)
