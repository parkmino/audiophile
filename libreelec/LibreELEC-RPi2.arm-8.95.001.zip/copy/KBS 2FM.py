import subprocess, xbmc, xbmcgui

url = subprocess.check_output('kr2url 2fm', shell=True)

listitem = xbmcgui.ListItem('KBS 2FM')
xbmc.Player().play(url, listitem)
